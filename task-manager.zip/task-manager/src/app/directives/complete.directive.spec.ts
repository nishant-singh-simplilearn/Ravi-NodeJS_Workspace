import { CompleteDirective } from './complete.directive';

describe('CompleteDirective', () => {
  it('should create an instance', () => {
    const directive = new CompleteDirective();
    expect(directive).toBeTruthy();
  });
});
