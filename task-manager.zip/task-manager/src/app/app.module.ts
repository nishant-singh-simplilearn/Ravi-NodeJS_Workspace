import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing/app-routing.module'

import { AppComponent } from './app.component';
import { TaskListComponent } from './components/task-manager/task-list/task-list.component';
import { CompleteDirective } from './directives/complete.directive';
import { MyUppercasePipe } from './pipes/my-uppercase.pipe';
import { TaskFormComponent } from './components/task-manager/task-form/task-form.component';
import { LoginComponent } from './components/login/login.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { TaskManagerComponent } from './components/task-manager/task-manager.component';
import { TaskDetailComponent } from './components/task-manager/task-detail/task-detail.component';
import { TaskNavComponent } from './components/task-manager/task-nav/task-nav.component';

@NgModule({
  declarations: [
    AppComponent,
    TaskListComponent,
    CompleteDirective,
    MyUppercasePipe,
    TaskFormComponent,
    LoginComponent,
    PageNotFoundComponent,
    TaskManagerComponent,
    TaskDetailComponent,
    TaskNavComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
