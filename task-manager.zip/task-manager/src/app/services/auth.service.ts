import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }
  
  login(creds) {
    if(creds.username === 'admin' && creds.password === 'admin123') {
        localStorage.setItem('user', creds.username)
        return true
    } else {
        return false
    }
  }
  
  logout() {
      localStorage.removeItem('user')
  }
  
  getUser() {
      return localStorage.getItem('user')
  }
}
