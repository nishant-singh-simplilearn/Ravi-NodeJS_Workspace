var http = require('http');
// var path = require('path');
var express = require('express');

var PORT = 4200;

var app = express();
var server = http.createServer(app);

app.set('view engine', 'ejs');

app.get('/', function(req, res) {
    // res.sendFile(path.join(__dirname, 'public/index.html'));
    var data = {
        title: 'Home Page!',
        body: 'This is the Home page.....'
    };
    res.render('page', data);
});

app.get('/about-us', function(req, res) {
     var data = {
        title: 'About Us',
        body: 'This is the About Us page.....'
    };
    res.render('page', data);
});

app.get('/services', function(req, res) {
    var data = {
        title: 'Services',
        body: 'This is the Services page.....',
        services: ['Web Design', 'Web Development', 'Digital Marketing']
    };
    res.render('page', data);
});

app.get('/contact-us', function(req, res) {
    var data = {
        title: 'Contact Us',
        body: 'This is the Contact Us page.....'
    };
    res.render('page', data);
});

app.get('**', function(req, res) {
    res.send('404 - Page Not Found');
});

server.listen(PORT, function() {
    console.log('Server Started on port ' + PORT);
});