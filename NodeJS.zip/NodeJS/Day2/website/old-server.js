var http = require('http');
var PORT = 4200;
var server = http.createServer(function(req, res) {
    switch(req.url) {
        case '/':
            res.end('Home Page');
            break;
        case '/services':
            res.end('Services');
            break;
        case '/contact-us':
            res.end('Contact Us');
            break;
        case '/about-us':
            res.end('About Us');
        default:
            res.statusCode = 404;
            res.end('Page Not Found');
    }
});

server.listen(PORT, function() {
    console.log('Server Started on port ' + PORT);
});