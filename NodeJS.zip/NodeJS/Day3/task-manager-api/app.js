var express = require('express');

var app = express();

app.get('/tasks', function(req, res) {
  res.send('Tasks GET Works!');
});

app.post('/tasks', function(req, res) {
  res.send('Tasks POST Works!');  
});

app.put('/tasks', function(req, res) {
  res.send('Tasks PUT Works!');
});

app.delete('/tasks', function(req, res) {
  res.send('Tasks Delete Works!');
});

app.patch('/tasks', function(req, res) {
  res.send('Tasks Patch Works!');
});

module.exports = app;