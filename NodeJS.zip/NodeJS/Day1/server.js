var http = require('http')
var PORT = 4200

var server = http.createServer(function(req, res) {
    /*res.setHeader('Content-type', 'text/html')
    res.statusCode = 200*/
    res.end('Hello World!')
})

server.listen(PORT, function() {
    console.log('Server Started on Port: ' + PORT)
})